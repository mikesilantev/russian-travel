# Проект 3: Путешествие по России
Страничка https://mikesilantev.github.io/russian-travel/index.html
Дистрибутив https://github.com/mikesilantev/russian-travel.git

# Проект 3: Путешествие по России
# 
# Кроссбраузерная верстка на гридах и флексе

ссылку на GitHub Pages.
